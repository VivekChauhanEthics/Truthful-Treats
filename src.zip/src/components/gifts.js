import React from 'react'
import "../css/style.css";
import "../Js/custom.js";

import  Header   from './header';
import  Footer   from './footer';

function Gifts() {
  return (
    <>
        <Header />
        <div><h1 class="text-center my-5">Not Available for now !</h1></div>
        <Footer />
    </>
    
  )
}

export default Gifts;