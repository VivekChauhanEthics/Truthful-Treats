
// function initializeOwlCarousel(selector, autoplayTimeout, responsiveOptions) {
//     $(selector).owlCarousel({
//         loop: true,
//         margin: 10,
//         nav: true,
//         dots: false,
//         autoplay: true,
//         autoplayTimeout: autoplayTimeout,
//         responsive: responsiveOptions
//     });
// }

// // home page main carousel
// initializeOwlCarousel('.OwlCarousel', 3000, {
//     0: { items: 1 },
//     600: { items: 2 },
//     1000: { items: 4 }
// });

// // home page instagram section
// initializeOwlCarousel('.owl-carousel-instagram', 3000, {
//     0: { items: 2 },
//     600: { items: 3 },
//     1000: { items: 4.5 }
// });

// // blog detail page
// initializeOwlCarousel('.blog-OwlCarousel', 4000, {
//     0: { items: 1 },
//     600: { items: 2 },
//     1000: { items: 3 }
// });
